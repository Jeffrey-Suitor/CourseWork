function output = create_identity(size)
    % Create an identity matrix given a size
    output = eye(size);
end