function output = inverse(matrix)
    % Invert a given matrix
    output = inv(matrix);
end