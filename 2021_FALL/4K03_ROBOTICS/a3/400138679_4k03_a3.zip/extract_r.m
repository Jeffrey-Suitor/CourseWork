function section = extract_r(matrix)
    section = matrix(1:3, 1:3);
end
